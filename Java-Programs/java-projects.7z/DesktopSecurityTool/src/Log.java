import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;


/*program to log user activity*/

public class Log extends JFrame implements Runnable{
    int i=0;
    Thread t1;
    public Log(){
        t1=new Thread(this);
        t1.start();
    }
    @Override
    public void run(){
        for(;;)
        {
            try{  
                Robot r =new Robot();
                BufferedImage img=r.createScreenCapture(
                new Rectangle(
                getToolkit().getScreenSize()));
                ImageIO.write(img, "jpg", new File("D:\\pic\\"+i+".jpg"));
                i++;
                t1.sleep(300);
            }
            catch(Exception ex){
                
            }
        }
    }
    public static void main(String args[]){
        
    }
}
