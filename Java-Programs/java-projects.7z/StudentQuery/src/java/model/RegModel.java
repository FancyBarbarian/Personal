package model;
import dbutil.DBConnect;
import java.sql.ResultSet;
public class RegModel {
    String email;
    String pass;
    String name;
    String mobile;
    String uType;
    String branch;

    public RegModel(String email, String pass, String name, String mobile, String uType, String branch) {
        this.email = email;
        this.pass = pass;
        this.name = name;
        this.mobile = mobile;
        this.uType = uType;
        this.branch = branch;
    }

    @Override
    public String toString() {
        return "RegModel{" + "email=" + email + ", pass=" + pass + ", name=" + name + ", mobile=" + mobile + ", uType=" + uType + ", branch=" + branch + '}';
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setuType(String uType) {
        this.uType = uType;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getEmail() {
        return email;
    }

    public String getPass() {
        return pass;
    }

    public String getName() {
        return name;
    }

    public String getMobile() {
        return mobile;
    }

    public String getuType() {
        return uType;
    }

    public String getBranch() {
        return branch;
    }
    
    public void submit() throws Exception{
        DBConnect x= new DBConnect();
        x.queryExecuter("insert into reg values('"
                + email+"','"
                + pass+"','"
                + name+"','"
                + mobile+"','"
                + uType+"','"
                + branch+"','");
    }
    
    public boolean checkUser(String e,String p) throws Exception{
        DBConnect x= new DBConnect();
        ResultSet rs=x.queryReturner("Select * from reg where email='"+
                e+"'and password='"+p+"'");
        if(rs.next())
        {
            this.email=rs.getString(1);
            this.pass=rs.getString(2);
            this.name=rs.getString(3);
            this.mobile=rs.getString(4);
            this.uType=rs.getString(5);
            this.branch=rs.getString(6);
            return true;
        }
        return false;
    }
}
